TIL A� KEYRA GUI:

Fyrst �arf a� downloada SIP og keyra configuration skr�na.
http://www.riverbankcomputing.co.uk/software/sip/download

S��an �arf a� b�ta �essu pakka vi� Python site-packages (hj� m�r C:\Python27\Lib\site-packages)
http://www.riverbankcomputing.co.uk/software/pyqt/download

VI� NOTUM MATPLOT TIL A� TEIKNA GR�F.